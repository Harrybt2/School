import os
os.system('python -m python_turbine_blade_designer --input config.yaml --output output')
print('If you see this before the graphs, we got a problem')